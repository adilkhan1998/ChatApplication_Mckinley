# Realtime Chat Application


Setup:
- run ```npm i && npm start``` for both client and server side to start the development server
